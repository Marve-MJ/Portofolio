<?php
require('fpdf/fpdf.php');
include 'config.php';
include 'phpqrcode/qrlib.php';

// Ambil data pesanan
$id = $_GET['id'];
$result = $conn->query("SELECT p.*, w.nama_tempat, w.harga AS harga_wisata,
                               m.nama_makanan, m.harga AS harga_makanan,
                               n.nama_minuman, n.harga AS harga_minuman
                        FROM pesanan p
                        LEFT JOIN pariwisata w ON p.pariwisata_id = w.id
                        LEFT JOIN makanan m ON p.makanan_id = m.id
                        LEFT JOIN minuman n ON p.minuman_id = n.id
                        WHERE p.id = $id");
$data = $result->fetch_assoc();

// Generate nomor invoice acak
$invoice = "INV-" . strtoupper(uniqid());

// Data untuk QR
$total = $data['harga_wisata'] + $data['harga_makanan'] + $data['harga_minuman'];
$qrContent = "Invoice: $invoice\n".
             "Nama: ".$data['nama']."\n".
             "Kontak: ".$data['kontak']."\n".
             "Pesanan: ".$data['nama_tempat'].", ".$data['nama_makanan'].", ".$data['nama_minuman']."\n".
             "Total: Rp ".number_format($total);

// Buat QR Code
$qrTemp = "qrcode.png";
QRcode::png($qrContent, $qrTemp, QR_ECLEVEL_L, 4);

// Mulai PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);

// Fungsi untuk menggambar border di sekeliling halaman
function drawBorder($pdf) {
    $pdf->SetLineWidth(0.5);
    $pdf->Rect(5, 5, 200, 287); // Border luar (ukuran A4: 210x297, dikurangi margin)
}

// Gambar border di awal
drawBorder($pdf);

// Logo di kiri atas - DIPERBESAR
$pdf->Image('logo.png',15,12,35); // diperbesar dari 25 menjadi 35

// Judul di tengah
$pdf->Cell(0,10,'PEMERINTAH KOTA SEMARANG',0,1,'C');
$pdf->Cell(0,10,'BUKTI PEMESANAN SEMARANGAN',0,1,'C');
$pdf->Ln(10);

// Identitas Pemesan (tanpa tabel)
$pdf->SetFont('Arial','',12);
$pdf->Cell(90,8,'Nama: '.$data['nama'],0,0,'L');
$pdf->Ln(8);
$pdf->Cell(90,8,'Kontak: '.$data['kontak'],0,0,'L');
$pdf->Ln(15); // Jarak sebelum invoice
$pdf->SetXY(110,40); // Posisi invoice di kanan
$pdf->Cell(80,8,'No. Invoice: '.$invoice,0,1,'R');

// Tabel Rincian Pesanan
$pdf->SetXY(10,70); // Posisi tabel di bawah
$pdf->SetFont('Arial','B',12);
$pdf->Cell(60,10,'Pesanan',1,0,'C');
$pdf->Cell(60,10,'Harga',1,0,'C');
$pdf->Cell(60,10,'Keterangan',1,1,'C');

$pdf->SetFont('Arial','',12);
// Baris 1: Tempat
$pdf->Cell(60,10,$data['nama_tempat'],1,0,'L');
$pdf->Cell(60,10,'Rp '.number_format($data['harga_wisata']),1,0,'R');
$pdf->Cell(60,10,'Tiket Masuk',1,1,'L');
// Baris 2: Makanan
$pdf->Cell(60,10,$data['nama_makanan'],1,0,'L');
$pdf->Cell(60,10,'Rp '.number_format($data['harga_makanan']),1,0,'R');
$pdf->Cell(60,10,'Makanan',1,1,'L');
// Baris 3: Minuman
$pdf->Cell(60,10,$data['nama_minuman'],1,0,'L');
$pdf->Cell(60,10,'Rp '.number_format($data['harga_minuman']),1,0,'R');
$pdf->Cell(60,10,'Minuman',1,1,'L');

$pdf->SetFont('Arial','B',12);
$pdf->Cell(60,10,'TOTAL',1,0,'C');
$pdf->Cell(60,10,'Rp '.number_format($total),1,0,'R');
$pdf->Cell(60,10,'',1,1,'L');

// QR Code di bawah tabel, kiri
$pdf->Image($qrTemp,25,150,40,40);

// Tanda tangan di bawah tabel, kanan
$pdf->SetXY(130,150);
$pdf->Cell(60,10,'Panitia Semarangan',0,1,'C');
$pdf->Image('ttd.jpg',145,160,40);
$pdf->SetXY(130,190);
$pdf->SetFont('Arial','',12);
$pdf->Cell(60,10,'Adhan',0,1,'C');

// Gambar border lagi di akhir untuk memastikan terlihat
drawBorder($pdf);

$pdf->Output();

// Hapus file QR code temporary
unlink($qrTemp);
?>