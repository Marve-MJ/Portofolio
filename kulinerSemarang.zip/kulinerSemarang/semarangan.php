<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SEMARANGAN</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");

      html {
        scroll-behavior: smooth;
      }

      body {
        margin: 0;
        background: grey;
        font-family: "Poppins", serif;
        font-optical-sizing: auto;
        font-weight: 300;
        font-style: normal;
        font-variation-settings: "slnt" 0;
      }

      .navbar {
        position: fixed;
        width: 100%;
        top: 0;
        left: 0;
        background: white;
        margin: 0;
        padding: 20px 50px;
        z-index: 1000;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }

      .logo {
        font-size: 19pt;
        font-weight: bold;
        text-decoration: none;
        color: black;
      }

      .container {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .tombol {
        display: none;
      }

      .tombol img {
        width: 30px;
        cursor: pointer;
      }

      .menu {
        margin: 0;
        display: flex;
        list-style: none;
        padding: 0;
      }

      .menu li {
        padding-right: 0px;
        position: relative;
      }

      .menu li a {
        padding: 10px;
        font-weight: 600;
        color: black;
        text-decoration: none;
        display: inline-block;
        border-radius: 8px;
        transition: background 0.3s ease, color 0.3s ease;
      }

      .menu li a:hover {
        background: orange;
        color: white;
      }

      @media screen and (max-width: 768px) {
        .navbar {
          padding: 20px;
        }

        .menu {
          display: none;
        }

        .menu.aktif {
          display: inline-block;
          position: absolute;
          top: 84px;
          background: white;
          padding: 10px 20px;
          right: 60px;
          left: auto;
          border-radius: 8px;
          text-align: right;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .menu li {
          position: static;
        }

        .menu.aktif li a {
          padding: 10px;
        }

        .menu li a:hover::after {
          width: 100%;
        }

        .tombol {
          display: block;
          margin-right: 40px;
        }
      }

      #home {
        background: url("images/header.jpg") no-repeat center center/cover;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
        text-align: center;
        position: relative;
      }

      .home-content {
        z-index: 1;
      }

      #home::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 0;
      }

      .home-content h1 {
        font-size: 48px;
        margin-bottom: 10px;
      }

      .home-content p {
        font-size: 24px;
      }

      #top_pariwisata {
        padding: 50px 20px;
        text-align: center;
        background-color: #f9f9f9;
      }

      #top_pariwisata h2 {
        font-size: 36px;
        color: #333;
        margin-bottom: 30px;
      }

      .carousel-container {
        max-width: 1200px;
        margin: 0 auto;
        overflow: hidden;
        position: relative;
      }

      .card-container {
        display: flex;
        animation: slide 40s linear infinite;
      }

      .card {
        flex: 0 0 300px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        text-align: center;
        margin: 10px;
      }

      .card img {
        width: 100%;
        height: 150px;
        object-fit: cover;
      }

      .card p {
        padding: 15px;
        font-size: 18px;
        color: black;
        font-weight: 600;
      }

      @keyframes slide {
        0% {
          transform: translateX(0);
        }
        100% {
          transform: translateX(calc(-300px * 10 - 10px * 10));
        }
      }

      #top_kuliner {
        padding: 50px 20px 30px;
        background-color: orange;
        color: white;
        text-align: center;
      }

      #top_kuliner h2 {
        font-size: 36px;
        margin-bottom: 30px;
      }

      .table-container {
        max-width: 800px;
        margin: 0 auto;
        overflow-x: auto;
      }

      table {
        width: 100%;
        border-collapse: collapse;
        color: white;
      }

      table th,
      table td {
        padding: 15px 20px;
        text-align: left;
      }

      table th {
        font-weight: bold;
        font-size: 20px;
        color: #333;
        background-color: rgba(255, 255, 255, 0.8);
        border-radius: 8px 8px 0 0;
      }

      table td {
        font-size: 18px;
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 8px;
      }

      table tr:nth-child(even) td {
        background-color: rgba(255, 255, 255, 0.2);
      }

      table tr:hover td {
        background-color: rgba(255, 255, 255, 0.3);
      }

      #pesan {
        padding: 50px 20px;
        background-color: white;
        color: #333;
        text-align: center;
      }

      #pesan h2 {
        font-size: 36px;
        margin-bottom: 30px;
      }

      form {
        max-width: 500px;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        gap: 20px;
      }

      .form-group {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
      }

      label {
        font-size: 18px;
        margin-bottom: 5px;
        color: #333;
      }

      input[type="text"],
      select {
        width: 100%;
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ddd;
        border-radius: 5px;
      }

      button[type="submit"] {
        padding: 12px;
        font-size: 18px;
        color: white;
        background-color: orange;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
      }

      button[type="submit"]:hover {
        background-color: rgb(223, 148, 10);
      }

      footer {
        background-color: orange;
        color: white;
        text-align: center;
        padding: 15px 0;
        font-size: 18px;
      }

      footer p {
        margin: 0;
        font-weight: 400;
      }
    </style>
  </head>
  <body>
    <header>
      <nav class="navbar">
        <div class="container">
          <a href="#" class="logo">SEMARANG<span style="color: red">an</span></a>
          <ul class="menu">
            <li><a href="#home">Home</a></li>
            <li><a href="#top_pariwisata">Pariwisata</a></li>
            <li><a href="#top_kuliner">Kuliner</a></li>
            <li><a href="#pesan">Pesan</a></li>
            <li style="padding-right: 90px"></li>
          </ul>
          <div class="tombol">
            <img src="images/burger-menu-svgrepo-com.svg" alt="Menu" id="hamburger-menu" />
          </div>
        </div>
      </nav>
    </header>

    <section id="home">
      <div class="home-content">
        <h1>Welcome to SEMARANG<span style="color: red">an</span></h1>
        <p>Temukan tempat, makanan, dan budaya terbaik</p>
      </div>
    </section>

    <section id="top_pariwisata">
      <h2>PARIWISATA</h2>
      <div class="carousel-container">
        <div class="card-container">
          <div class="card">
            <img src="images/dusunsemilirr.jpg" alt="dusunsemilir" />
            <p>Dusun Semilir</p>
          </div>
          <div class="card">
            <img src="images/marina.jpg" alt="marina" />
            <p>Pantai Marina</p>
          </div>
          <div class="card">
            <img src="images/majt.jpg" alt="majt" />
            <p>Masjid Agung Jateng</p>
          </div>
          <div class="card">
            <img src="images/kotalama.jpg" alt="kotalama" />
            <p>Kota Lama</p>
          </div>
          <div class="card">
            <img src="images/lawangsewu.jpg" alt="lawangsewu" />
            <p>Lawang Sewu</p>
          </div>
          <div class="card">
            <img src="images/sampokong.jpg" alt="sampokong" />
            <p>Klenteng SampoKong</p>
          </div>
          <div class="card">
            <img src="images/semawis.jpg" alt="semawis" />
            <p>Pasar Semawis</p>
          </div>
          <div class="card">
            <img src="images/candigedong9.jpg" alt="gedungsongo" />
            <p>Candi Gedung Songo</p>
          </div>
          <div class="card">
            <img src="images/museumronggowarsito.jpg" alt="ronggowarsito" />
            <p>Museum Ronggowarsito</p>
          </div>
          <div class="card">
            <img src="images/cimory.jpg" alt="cimory" />
            <p>Cimory The Valley</p>
          </div>
          <!-- Duplicate cards for seamless looping -->
          <div class="card">
            <img src="images/dusunsemilirr.jpg" alt="dusunsemilir" />
            <p>Dusun Semilir</p>
          </div>
          <div class="card">
            <img src="images/marina.jpg" alt="marina" />
            <p>Pantai Marina</p>
          </div>
          <div class="card">
            <img src="images/majt.jpg" alt="majt" />
            <p>Masjid Agung Jateng</p>
          </div>
          <div class="card">
            <img src="images/kotalama.jpg" alt="kotalama" />
            <p>Kota Lama</p>
          </div>
          <div class="card">
            <img src="images/lawangsewu.jpg" alt="lawangsewu" />
            <p>Lawang Sewu</p>
          </div>
          <div class="card">
            <img src="images/sampokong.jpg" alt="sampokong" />
            <p>Klenteng SampoKong</p>
          </div>
          <div class="card">
            <img src="images/semawis.jpg" alt="semawis" />
            <p>Pasar Semawis</p>
          </div>
          <div class="card">
            <img src="images/candigedong9.jpg" alt="gedungsongo" />
            <p>Candi Gedung Songo</p>
          </div>
          <div class="card">
            <img src="images/museumronggowarsito.jpg" alt="ronggowarsito" />
            <p>Museum Ronggowarsito</p>
          </div>
          <div class="card">
            <img src="images/cimory.jpg" alt="cimory" />
            <p>Cimory The Valley</p>
          </div>
        </div>
      </div>
    </section>

    <section id="top_kuliner">
      <h2>KULINER</h2>
      <div class="table-container">
        <table>
          <tr>
            <th width="22%">Nama Kuliner</th>
            <th width="71%">Deskripsi</th>
            <th width="12%">Harga</th>
          </tr>
          <tr>
            <td>Tahu Gimbal</td>
            <td>
              Tahu Gimbal yang berisi Tahu, saos kacang, gimbal serta tauge yang khas semarangan.
            </td>
            <td>Rp 25.000</td>
          </tr>
          <tr>
            <td>Lunpia Semarang</td>
            <td>
              Jajanan Khas semarang yang terbuat dari rebung, telur, udang dan dilapisi oleh kulit Lunpia.
            </td>
            <td>Rp 20.000</td>
          </tr>
          <tr>
            <td>Wingko babat</td>
            <td>
              Kue khas Semarang yang terbuat dari tepung terigu, gula serta bahan lain nya.
            </td>
            <td>Rp 10.000</td>
          </tr>
          <tr>
            <td>Roti Ganjel Rel</td>
            <td>Roti Khas Semarang yang lezat dan enak terbuat dari tepung terigu dan bahan lainnya.</td>
            <td>Rp 15.000</td>
          </tr>
          <tr>
            <td>Bandeng Presto</td>
            <td>
              Makanan Olahan bandeng yang terdiri dari ikan bandeng yang di presto sehingga menghasilkan daging yang lembut tanpa duri.
            </td>
            <td>Rp 22.000</td>
          </tr>
        </table>
      </div>
    </section>

    <section id="pesan">
      <h2>Pesan Sekarang</h2>
      <form action="simpan_pesanan.php" method="post">
        <div class="form-group">
          <label for="name">Nama:</label>
          <input type="text" id="name" name="name" required />
        </div>
        <div class="form-group">
          <label for="contact">Kontak:</label>
          <input type="text" id="contact" name="contact" required />
        </div>
        <div class="form-group">
          <label for="pariwisata_id">Pilih Pariwisata:</label>
          <select id="pariwisata_id" name="pariwisata_id">
            <option value="" disabled selected>-- Pilih Pariwisata --</option>
            <?php
            $result = $conn->query("SELECT id, nama_tempat, harga FROM pariwisata");
            while($row = $result->fetch_assoc()){
              echo "<option value='".$row['id']."'>".$row['nama_tempat']." - Rp ".$row['harga']."</option>";
            }
            ?>
          </select>
        </div>
        <div class="form-group">
          <label for="makanan_id">Pilih Makanan:</label>
          <select id="makanan_id" name="makanan_id">
            <option value="" disabled selected>-- Pilih Makanan --</option>
            <?php
            $result = $conn->query("SELECT id, nama_makanan, harga FROM makanan");
            while($row = $result->fetch_assoc()){
              echo "<option value='".$row['id']."'>".$row['nama_makanan']." - Rp ".$row['harga']."</option>";
            }
            ?>
          </select>
        </div>
        <div class="form-group">
          <label for="minuman_id">Pilih Minuman:</label>
          <select id="minuman_id" name="minuman_id">
            <option value="" disabled selected>-- Pilih Minuman --</option>
            <?php
            $result = $conn->query("SELECT id, nama_minuman, harga FROM minuman");
            while($row = $result->fetch_assoc()){
              echo "<option value='".$row['id']."'>".$row['nama_minuman']." - Rp ".$row['harga']."</option>";
            }
            ?>
          </select>
        </div>
        <button type="submit">Pesan
