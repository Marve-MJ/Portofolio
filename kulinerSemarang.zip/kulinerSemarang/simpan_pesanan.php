<?php
include 'config.php';

// Ambil data dari form
$nama         = $_POST['name'];
$kontak       = $_POST['contact'];
$pariwisata_id= $_POST['pariwisata_id'];
$makanan_id   = $_POST['makanan_id'];
$minuman_id   = $_POST['minuman_id'];

$sql = "INSERT INTO pesanan (nama, kontak, pariwisata_id, makanan_id, minuman_id) 
        VALUES ('$nama', '$kontak', '$pariwisata_id', '$makanan_id', '$minuman_id')";

if ($conn->query($sql) === TRUE) {
    $last_id = $conn->insert_id;
    header("Location: cetak.php?id=$last_id");
    exit();
} else {
    echo "Error: " . $conn->error;
}
?>
