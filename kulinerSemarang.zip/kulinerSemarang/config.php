<?php
$host = "localhost";
$user = "root";      // ganti kalau pakai user lain
$pass = "";          // ganti kalau pakai password
$db   = "semarangan";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
